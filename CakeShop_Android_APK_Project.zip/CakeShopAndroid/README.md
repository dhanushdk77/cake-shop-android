# Cake Shop Android App (Offline APK project)

This Android Studio project packages the cake shop app directly inside an Android WebView. The app works offline for product browsing, order entry, admin management and reports. Data is stored locally on that phone using WebView local storage.

## Build the APK (Windows / Mac / Linux)
1. Install **Android Studio** (current stable) and its Android SDK Platform 35.
2. Extract this ZIP.
3. Open Android Studio → **Open** → select the `CakeShopAndroid` folder (the folder containing `settings.gradle`).
4. Wait for Gradle sync and SDK downloads to finish.
5. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. When complete, click **locate** in the notification. APK output is normally `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer the APK to your Android phone, tap it, and allow **Install unknown apps** for the file manager if Android asks.

## First use
- Open app → Shop tab for customer ordering.
- Admin tab → login username `admin`, password `admin123`.
- Change the demo password from Admin → Security.
- Use Products to add/edit/delete cakes. Orders displays requests and lets you update status.
- Use Export CSV to share an order report.

## Important data and business notes
- This is a standalone offline app. Data is stored on the device where orders are entered. It does not automatically sync to another phone, website, or cloud database.
- Uninstalling or clearing app storage can erase local products and orders. Export reports and keep backups.
- Set the WhatsApp contact in the app Settings before sharing it with customers.
- The initial admin password is a demo credential; change it before real use.
- This starter does not process online payments or send automatic WhatsApp messages. WhatsApp opens a prefilled message for the shop contact; the user presses Send.
- To collect orders from customers on their own phones into one central admin dashboard, the app needs a hosted backend/API and internet connectivity. This offline build does not provide centralised multi-device ordering.

## Project requirements
- Android Studio
- Android SDK Platform 35
- Java 17 (Android Studio bundled JBR is suitable)
